// import CrossCircledIcon from '~icons/radix-icons/cross-circled'
// import QuestionMarkCircledIcon from '~icons/radix-icons/question-mark-circled'

import { Icon } from "#components";

export const types = [
  {
    value: "Выходной",
    label: "Выходной",
  },
  {
    value: "Рабочий день",
    label: "Рабочий день",
  },
  {
    value: "Форс мажор",
    label: "Форс мажор",
  },
];





