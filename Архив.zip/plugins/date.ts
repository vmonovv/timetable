import {
  CalendarDate,
  DateFormatter,
  getLocalTimeZone,
} from "@internationalized/date";

export default defineNuxtPlugin((nuxtApp) => {});
