<template>
  <section class="container">
    <div class="flex justify-center h-[100vh] items-center flex-col">
      <div class="text-[100px] text-black">404</div>
      <NuxtLink
        class="s mt-0 inline-block px-4 py-2 border-2 border-[#0070FF] text-[#0070FF] hover:bg-[#0070FF] hover:text-white font-medium transition duration-300 ease-in-out rounded-lg"
        to="/profile"
        >вернуться домой</NuxtLink
      >
    </div>
  </section>
</template>

<script setup></script>

<style lang="scss" scoped></style>
