<template>
  <div
    class="wrapper bg-sidebar flex items-center justify-center w-screen h-screen"
  >
    <img class="max-w-[100px]" src="/loader.gif" alt="" width="220" />
  </div>
</template>
