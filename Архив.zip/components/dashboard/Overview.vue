<script setup lang="ts">
import analyticsQuantity from "@/data/analytics/quantity.json";

const data = [
  {
    name: "Денс",
    Количество: 1970,
  },
  {
    name: "КТ",
    Количество: 4437,
    "С КУ 1 Зона": 508,
    "С КУ 2 и более зон": 541,
  },
  {
    name: "МРТ",
    Количество: 1675,
    "С КУ 1 Зона": 817,
    "С КУ 2 и более зон": 14,
  },
];
</script>

<template>



</template>
<style>
.css-1w4dk9t-tick text {
  fill: #828080 !important;
}
</style>
