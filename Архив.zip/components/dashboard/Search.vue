<script setup lang="ts"></script>

<template>
  <div>
    <Input
      type="search"
      placeholder="Поиск..."
      class="md:w-[100px] lg:w-[300px]"
    />
  </div>
</template>
