// import { createClient } from "@supabase/supabase-js";

// // const supabaseUrl = process.env.SUPABASE_URL || "default_url";
// // const supabaseKey = process.env.SUPABASE_KEY || "default_key";
// const supabaseUrl = "https://ecyhmupsgrzfccdmokcq.supabase.co";
// const supabaseKey =
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjeWhtdXBzZ3J6ZmNjZG1va2NxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTczNTQ0NjAsImV4cCI6MjAzMjkzMDQ2MH0.pQOknJQqgTQt3sWgsNovj2AhKOAqmGJ826AHiPsJcq0";

// export const supabase = createClient(supabaseUrl, supabaseKey);
